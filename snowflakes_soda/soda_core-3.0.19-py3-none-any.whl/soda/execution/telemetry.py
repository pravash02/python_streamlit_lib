class Telemetry:
    pass
