# Generated from /Users/m1n0/dev/soda/soda-sql/soda-core/soda/core/soda/sodacl/antlr/SodaCLAntlr.g4 by ANTLR 4.11.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,55,385,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        2,40,7,40,1,0,1,0,1,0,1,0,1,0,3,0,88,8,0,1,1,1,1,1,1,1,1,3,1,94,
        8,1,1,1,1,1,1,1,1,1,3,1,100,8,1,1,1,1,1,1,2,1,2,1,2,1,2,1,2,1,3,
        1,3,1,3,1,4,1,4,1,4,1,5,1,5,1,5,1,5,1,5,3,5,120,8,5,1,5,1,5,1,5,
        1,5,3,5,126,8,5,1,5,1,5,1,6,1,6,3,6,132,8,6,1,6,1,6,1,6,1,6,3,6,
        138,8,6,3,6,140,8,6,1,6,1,6,1,7,1,7,1,7,1,7,1,8,1,8,1,8,1,8,1,8,
        3,8,153,8,8,1,8,3,8,156,8,8,1,8,1,8,1,8,1,9,1,9,1,9,1,9,1,9,1,9,
        1,9,3,9,168,8,9,1,10,1,10,1,11,1,11,1,12,1,12,1,12,1,13,1,13,1,14,
        1,14,3,14,181,8,14,1,15,1,15,1,16,1,16,1,16,1,16,1,16,5,16,190,8,
        16,10,16,12,16,193,9,16,1,16,1,16,1,17,1,17,3,17,199,8,17,1,18,1,
        18,3,18,203,8,18,1,19,1,19,3,19,207,8,19,1,19,1,19,1,19,3,19,212,
        8,19,1,19,1,19,1,19,1,19,1,19,1,19,3,19,220,8,19,1,20,1,20,1,20,
        1,20,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,4,21,235,8,21,
        11,21,12,21,236,1,21,1,21,1,22,1,22,1,23,1,23,1,24,1,24,1,25,1,25,
        3,25,249,8,25,1,25,3,25,252,8,25,1,25,1,25,3,25,256,8,25,1,26,1,
        26,1,26,4,26,261,8,26,11,26,12,26,262,1,26,3,26,266,8,26,1,27,1,
        27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,
        27,1,27,1,27,5,27,285,8,27,10,27,12,27,288,9,27,1,27,1,27,1,27,1,
        27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,5,27,301,8,27,10,27,12,27,
        304,9,27,1,27,1,27,3,27,308,8,27,1,28,1,28,1,29,1,29,1,30,1,30,1,
        30,1,30,1,30,3,30,319,8,30,1,31,1,31,1,31,1,31,1,31,3,31,326,8,31,
        1,31,1,31,1,32,1,32,1,32,1,32,1,33,1,33,1,33,1,33,1,33,1,33,1,33,
        1,34,1,34,1,34,1,34,1,34,1,35,1,35,1,35,1,35,1,35,1,35,1,35,1,35,
        1,35,1,35,3,35,356,8,35,1,36,1,36,1,36,1,36,1,36,1,37,3,37,364,8,
        37,1,37,1,37,1,38,1,38,1,38,1,38,3,38,372,8,38,1,38,3,38,375,8,38,
        1,38,1,38,3,38,379,8,38,1,39,1,39,1,40,1,40,1,40,0,0,41,0,2,4,6,
        8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,
        52,54,56,58,60,62,64,66,68,70,72,74,76,78,80,0,9,1,0,30,32,2,0,33,
        33,37,37,2,0,34,34,38,38,1,0,25,27,2,0,45,45,48,48,1,0,43,49,1,0,
        8,10,1,0,41,42,2,0,30,32,50,52,386,0,87,1,0,0,0,2,89,1,0,0,0,4,103,
        1,0,0,0,6,108,1,0,0,0,8,111,1,0,0,0,10,114,1,0,0,0,12,131,1,0,0,
        0,14,143,1,0,0,0,16,147,1,0,0,0,18,167,1,0,0,0,20,169,1,0,0,0,22,
        171,1,0,0,0,24,173,1,0,0,0,26,176,1,0,0,0,28,178,1,0,0,0,30,182,
        1,0,0,0,32,184,1,0,0,0,34,198,1,0,0,0,36,202,1,0,0,0,38,206,1,0,
        0,0,40,221,1,0,0,0,42,234,1,0,0,0,44,240,1,0,0,0,46,242,1,0,0,0,
        48,244,1,0,0,0,50,255,1,0,0,0,52,260,1,0,0,0,54,307,1,0,0,0,56,309,
        1,0,0,0,58,311,1,0,0,0,60,318,1,0,0,0,62,320,1,0,0,0,64,329,1,0,
        0,0,66,333,1,0,0,0,68,340,1,0,0,0,70,355,1,0,0,0,72,357,1,0,0,0,
        74,363,1,0,0,0,76,378,1,0,0,0,78,380,1,0,0,0,80,382,1,0,0,0,82,88,
        3,8,4,0,83,88,3,10,5,0,84,88,3,12,6,0,85,88,3,54,27,0,86,88,3,2,
        1,0,87,82,1,0,0,0,87,83,1,0,0,0,87,84,1,0,0,0,87,85,1,0,0,0,87,86,
        1,0,0,0,88,1,1,0,0,0,89,90,5,1,0,0,90,91,5,55,0,0,91,93,3,80,40,
        0,92,94,3,4,2,0,93,92,1,0,0,0,93,94,1,0,0,0,94,99,1,0,0,0,95,96,
        5,55,0,0,96,97,5,48,0,0,97,98,5,55,0,0,98,100,3,52,26,0,99,95,1,
        0,0,0,99,100,1,0,0,0,100,101,1,0,0,0,101,102,5,0,0,1,102,3,1,0,0,
        0,103,104,5,55,0,0,104,105,5,2,0,0,105,106,5,55,0,0,106,107,3,80,
        40,0,107,5,1,0,0,0,108,109,5,55,0,0,109,110,5,25,0,0,110,7,1,0,0,
        0,111,112,5,50,0,0,112,113,5,0,0,1,113,9,1,0,0,0,114,115,5,3,0,0,
        115,116,5,55,0,0,116,119,3,80,40,0,117,118,5,55,0,0,118,120,3,64,
        32,0,119,117,1,0,0,0,119,120,1,0,0,0,120,125,1,0,0,0,121,122,5,55,
        0,0,122,123,5,24,0,0,123,124,5,55,0,0,124,126,3,80,40,0,125,121,
        1,0,0,0,125,126,1,0,0,0,126,127,1,0,0,0,127,128,5,0,0,1,128,11,1,
        0,0,0,129,132,3,16,8,0,130,132,3,26,13,0,131,129,1,0,0,0,131,130,
        1,0,0,0,131,132,1,0,0,0,132,133,1,0,0,0,133,139,3,28,14,0,134,137,
        5,55,0,0,135,138,3,36,18,0,136,138,3,14,7,0,137,135,1,0,0,0,137,
        136,1,0,0,0,138,140,1,0,0,0,139,134,1,0,0,0,139,140,1,0,0,0,140,
        141,1,0,0,0,141,142,5,0,0,1,142,13,1,0,0,0,143,144,5,48,0,0,144,
        145,5,55,0,0,145,146,5,4,0,0,146,15,1,0,0,0,147,148,5,28,0,0,148,
        152,5,55,0,0,149,150,3,18,9,0,150,151,5,55,0,0,151,153,1,0,0,0,152,
        149,1,0,0,0,152,153,1,0,0,0,153,155,1,0,0,0,154,156,3,24,12,0,155,
        154,1,0,0,0,155,156,1,0,0,0,156,157,1,0,0,0,157,158,5,20,0,0,158,
        159,5,55,0,0,159,17,1,0,0,0,160,161,3,20,10,0,161,162,5,55,0,0,162,
        163,5,29,0,0,163,164,5,55,0,0,164,165,3,78,39,0,165,168,1,0,0,0,
        166,168,3,22,11,0,167,160,1,0,0,0,167,166,1,0,0,0,168,19,1,0,0,0,
        169,170,7,0,0,0,170,21,1,0,0,0,171,172,5,5,0,0,172,23,1,0,0,0,173,
        174,5,6,0,0,174,175,5,55,0,0,175,25,1,0,0,0,176,177,5,7,0,0,177,
        27,1,0,0,0,178,180,3,30,15,0,179,181,3,32,16,0,180,179,1,0,0,0,180,
        181,1,0,0,0,181,29,1,0,0,0,182,183,3,80,40,0,183,31,1,0,0,0,184,
        185,5,37,0,0,185,191,3,34,17,0,186,187,5,39,0,0,187,188,5,55,0,0,
        188,190,3,34,17,0,189,186,1,0,0,0,190,193,1,0,0,0,191,189,1,0,0,
        0,191,192,1,0,0,0,192,194,1,0,0,0,193,191,1,0,0,0,194,195,5,38,0,
        0,195,33,1,0,0,0,196,199,3,74,37,0,197,199,3,80,40,0,198,196,1,0,
        0,0,198,197,1,0,0,0,199,35,1,0,0,0,200,203,3,40,20,0,201,203,3,38,
        19,0,202,200,1,0,0,0,202,201,1,0,0,0,203,37,1,0,0,0,204,205,5,23,
        0,0,205,207,5,55,0,0,206,204,1,0,0,0,206,207,1,0,0,0,207,208,1,0,
        0,0,208,209,5,22,0,0,209,211,5,55,0,0,210,212,7,1,0,0,211,210,1,
        0,0,0,211,212,1,0,0,0,212,213,1,0,0,0,213,214,3,50,25,0,214,215,
        5,55,0,0,215,216,5,21,0,0,216,217,5,55,0,0,217,219,3,50,25,0,218,
        220,7,2,0,0,219,218,1,0,0,0,219,220,1,0,0,0,220,39,1,0,0,0,221,222,
        3,48,24,0,222,223,5,55,0,0,223,224,3,50,25,0,224,41,1,0,0,0,225,
        226,3,44,22,0,226,227,5,55,0,0,227,228,3,46,23,0,228,229,5,55,0,
        0,229,230,3,50,25,0,230,231,5,55,0,0,231,232,3,46,23,0,232,233,5,
        55,0,0,233,235,1,0,0,0,234,225,1,0,0,0,235,236,1,0,0,0,236,234,1,
        0,0,0,236,237,1,0,0,0,237,238,1,0,0,0,238,239,3,44,22,0,239,43,1,
        0,0,0,240,241,7,3,0,0,241,45,1,0,0,0,242,243,7,4,0,0,243,47,1,0,
        0,0,244,245,7,5,0,0,245,49,1,0,0,0,246,251,3,74,37,0,247,249,5,55,
        0,0,248,247,1,0,0,0,248,249,1,0,0,0,249,250,1,0,0,0,250,252,5,40,
        0,0,251,248,1,0,0,0,251,252,1,0,0,0,252,256,1,0,0,0,253,256,3,52,
        26,0,254,256,5,52,0,0,255,246,1,0,0,0,255,253,1,0,0,0,255,254,1,
        0,0,0,256,51,1,0,0,0,257,258,3,78,39,0,258,259,7,6,0,0,259,261,1,
        0,0,0,260,257,1,0,0,0,261,262,1,0,0,0,262,260,1,0,0,0,262,263,1,
        0,0,0,263,265,1,0,0,0,264,266,3,78,39,0,265,264,1,0,0,0,265,266,
        1,0,0,0,266,53,1,0,0,0,267,268,5,11,0,0,268,269,5,55,0,0,269,270,
        3,56,28,0,270,271,5,55,0,0,271,272,5,12,0,0,272,273,5,55,0,0,273,
        274,3,80,40,0,274,275,5,55,0,0,275,276,3,58,29,0,276,308,1,0,0,0,
        277,278,5,11,0,0,278,279,5,55,0,0,279,280,5,37,0,0,280,286,3,56,
        28,0,281,282,5,39,0,0,282,283,5,55,0,0,283,285,3,56,28,0,284,281,
        1,0,0,0,285,288,1,0,0,0,286,284,1,0,0,0,286,287,1,0,0,0,287,289,
        1,0,0,0,288,286,1,0,0,0,289,290,5,38,0,0,290,291,5,55,0,0,291,292,
        5,12,0,0,292,293,5,55,0,0,293,294,3,80,40,0,294,295,5,55,0,0,295,
        296,5,37,0,0,296,302,3,58,29,0,297,298,5,39,0,0,298,299,5,55,0,0,
        299,301,3,58,29,0,300,297,1,0,0,0,301,304,1,0,0,0,302,300,1,0,0,
        0,302,303,1,0,0,0,303,305,1,0,0,0,304,302,1,0,0,0,305,306,5,38,0,
        0,306,308,1,0,0,0,307,267,1,0,0,0,307,277,1,0,0,0,308,55,1,0,0,0,
        309,310,3,80,40,0,310,57,1,0,0,0,311,312,3,80,40,0,312,59,1,0,0,
        0,313,319,3,62,31,0,314,319,3,68,34,0,315,319,3,66,33,0,316,319,
        3,70,35,0,317,319,3,72,36,0,318,313,1,0,0,0,318,314,1,0,0,0,318,
        315,1,0,0,0,318,316,1,0,0,0,318,317,1,0,0,0,319,61,1,0,0,0,320,321,
        5,13,0,0,321,322,5,55,0,0,322,325,3,80,40,0,323,324,5,55,0,0,324,
        326,3,64,32,0,325,323,1,0,0,0,325,326,1,0,0,0,326,327,1,0,0,0,327,
        328,5,0,0,1,328,63,1,0,0,0,329,330,5,33,0,0,330,331,3,80,40,0,331,
        332,5,34,0,0,332,65,1,0,0,0,333,334,5,14,0,0,334,335,5,55,0,0,335,
        336,3,80,40,0,336,337,5,55,0,0,337,338,3,64,32,0,338,339,5,0,0,1,
        339,67,1,0,0,0,340,341,5,15,0,0,341,342,5,55,0,0,342,343,3,80,40,
        0,343,344,5,0,0,1,344,69,1,0,0,0,345,346,5,16,0,0,346,347,5,55,0,
        0,347,348,3,80,40,0,348,349,5,0,0,1,349,356,1,0,0,0,350,351,5,17,
        0,0,351,352,5,55,0,0,352,353,3,80,40,0,353,354,5,0,0,1,354,356,1,
        0,0,0,355,345,1,0,0,0,355,350,1,0,0,0,356,71,1,0,0,0,357,358,5,18,
        0,0,358,359,5,55,0,0,359,360,3,80,40,0,360,361,5,0,0,1,361,73,1,
        0,0,0,362,364,7,7,0,0,363,362,1,0,0,0,363,364,1,0,0,0,364,365,1,
        0,0,0,365,366,3,76,38,0,366,75,1,0,0,0,367,379,3,78,39,0,368,369,
        5,54,0,0,369,371,5,19,0,0,370,372,5,54,0,0,371,370,1,0,0,0,371,372,
        1,0,0,0,372,379,1,0,0,0,373,375,5,54,0,0,374,373,1,0,0,0,374,375,
        1,0,0,0,375,376,1,0,0,0,376,377,5,19,0,0,377,379,5,54,0,0,378,367,
        1,0,0,0,378,368,1,0,0,0,378,374,1,0,0,0,379,77,1,0,0,0,380,381,5,
        54,0,0,381,79,1,0,0,0,382,383,7,8,0,0,383,81,1,0,0,0,34,87,93,99,
        119,125,131,137,139,152,155,167,180,191,198,202,206,211,219,236,
        248,251,255,262,265,286,302,307,318,325,355,363,371,374,378
    ]

class SodaCLAntlrParser ( Parser ):

    grammarFileName = "SodaCLAntlr.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'freshness using'", "'with'", "'row_count same as'", 
                     "'default'", "'same day last week'", "'percent'", "'anomaly score for '", 
                     "'d'", "'h'", "'m'", "'values in'", "'must exist in'", 
                     "'checks for'", "'filter'", "'configurations for'", 
                     "'for each dataset'", "'for each table'", "'for each column'", 
                     "'.'", "'for'", "'and'", "'between'", "'not'", "'in'", 
                     "'warn'", "'fail'", "'pass'", "'change'", "'last'", 
                     "'avg'", "'min'", "'max'", "'['", "']'", "'{'", "'}'", 
                     "'('", "')'", "','", "'%'", "'+'", "'-'", "'!='", "'<>'", 
                     "'<='", "'>='", "'='", "'<'", "'>'", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "' '" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "FOR", "AND", "BETWEEN", "NOT", "IN", "WARN", "FAIL", 
                      "PASS", "CHANGE", "LAST", "AVG", "MIN", "MAX", "SQUARE_LEFT", 
                      "SQUARE_RIGHT", "CURLY_LEFT", "CURLY_RIGHT", "ROUND_LEFT", 
                      "ROUND_RIGHT", "COMMA", "PERCENT", "PLUS", "MINUS", 
                      "NOT_EQUAL", "NOT_EQUAL_SQL", "LTE", "GTE", "EQUAL", 
                      "LT", "GT", "IDENTIFIER_DOUBLE_QUOTE", "IDENTIFIER_BACKTICK", 
                      "IDENTIFIER_UNQUOTED", "STRING", "DIGITS", "S" ]

    RULE_check = 0
    RULE_freshness_check = 1
    RULE_freshness_variable = 2
    RULE_warn_qualifier = 3
    RULE_failed_rows_check = 4
    RULE_row_count_comparison_check = 5
    RULE_metric_check = 6
    RULE_default_anomaly_threshold = 7
    RULE_change_over_time = 8
    RULE_change_over_time_config = 9
    RULE_change_aggregation = 10
    RULE_same_day_last_week = 11
    RULE_percent = 12
    RULE_anomaly_score = 13
    RULE_metric = 14
    RULE_metric_name = 15
    RULE_metric_args = 16
    RULE_metric_arg = 17
    RULE_threshold = 18
    RULE_between_threshold = 19
    RULE_comparator_threshold = 20
    RULE_zones_threshold = 21
    RULE_outcome = 22
    RULE_zone_comparator = 23
    RULE_comparator = 24
    RULE_threshold_value = 25
    RULE_freshness_threshold_value = 26
    RULE_reference_check = 27
    RULE_source_column_name = 28
    RULE_target_column_name = 29
    RULE_section_header = 30
    RULE_table_checks_header = 31
    RULE_partition_name = 32
    RULE_table_filter_header = 33
    RULE_column_configurations_header = 34
    RULE_checks_for_each_dataset_header = 35
    RULE_checks_for_each_column_header = 36
    RULE_signed_number = 37
    RULE_number = 38
    RULE_integer = 39
    RULE_identifier = 40

    ruleNames =  [ "check", "freshness_check", "freshness_variable", "warn_qualifier", 
                   "failed_rows_check", "row_count_comparison_check", "metric_check", 
                   "default_anomaly_threshold", "change_over_time", "change_over_time_config", 
                   "change_aggregation", "same_day_last_week", "percent", 
                   "anomaly_score", "metric", "metric_name", "metric_args", 
                   "metric_arg", "threshold", "between_threshold", "comparator_threshold", 
                   "zones_threshold", "outcome", "zone_comparator", "comparator", 
                   "threshold_value", "freshness_threshold_value", "reference_check", 
                   "source_column_name", "target_column_name", "section_header", 
                   "table_checks_header", "partition_name", "table_filter_header", 
                   "column_configurations_header", "checks_for_each_dataset_header", 
                   "checks_for_each_column_header", "signed_number", "number", 
                   "integer", "identifier" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    FOR=20
    AND=21
    BETWEEN=22
    NOT=23
    IN=24
    WARN=25
    FAIL=26
    PASS=27
    CHANGE=28
    LAST=29
    AVG=30
    MIN=31
    MAX=32
    SQUARE_LEFT=33
    SQUARE_RIGHT=34
    CURLY_LEFT=35
    CURLY_RIGHT=36
    ROUND_LEFT=37
    ROUND_RIGHT=38
    COMMA=39
    PERCENT=40
    PLUS=41
    MINUS=42
    NOT_EQUAL=43
    NOT_EQUAL_SQL=44
    LTE=45
    GTE=46
    EQUAL=47
    LT=48
    GT=49
    IDENTIFIER_DOUBLE_QUOTE=50
    IDENTIFIER_BACKTICK=51
    IDENTIFIER_UNQUOTED=52
    STRING=53
    DIGITS=54
    S=55

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.11.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class CheckContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def failed_rows_check(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Failed_rows_checkContext,0)


        def row_count_comparison_check(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Row_count_comparison_checkContext,0)


        def metric_check(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Metric_checkContext,0)


        def reference_check(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Reference_checkContext,0)


        def freshness_check(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Freshness_checkContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_check

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCheck" ):
                listener.enterCheck(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCheck" ):
                listener.exitCheck(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCheck" ):
                return visitor.visitCheck(self)
            else:
                return visitor.visitChildren(self)




    def check(self):

        localctx = SodaCLAntlrParser.CheckContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_check)
        try:
            self.state = 87
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 82
                self.failed_rows_check()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 83
                self.row_count_comparison_check()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 84
                self.metric_check()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 85
                self.reference_check()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 86
                self.freshness_check()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Freshness_checkContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def EOF(self):
            return self.getToken(SodaCLAntlrParser.EOF, 0)

        def freshness_variable(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Freshness_variableContext,0)


        def LT(self):
            return self.getToken(SodaCLAntlrParser.LT, 0)

        def freshness_threshold_value(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Freshness_threshold_valueContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_freshness_check

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFreshness_check" ):
                listener.enterFreshness_check(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFreshness_check" ):
                listener.exitFreshness_check(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFreshness_check" ):
                return visitor.visitFreshness_check(self)
            else:
                return visitor.visitChildren(self)




    def freshness_check(self):

        localctx = SodaCLAntlrParser.Freshness_checkContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_freshness_check)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 89
            self.match(SodaCLAntlrParser.T__0)
            self.state = 90
            self.match(SodaCLAntlrParser.S)
            self.state = 91
            self.identifier()
            self.state = 93
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.state = 92
                self.freshness_variable()


            self.state = 99
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==55:
                self.state = 95
                self.match(SodaCLAntlrParser.S)
                self.state = 96
                self.match(SodaCLAntlrParser.LT)
                self.state = 97
                self.match(SodaCLAntlrParser.S)
                self.state = 98
                self.freshness_threshold_value()


            self.state = 101
            self.match(SodaCLAntlrParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Freshness_variableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_freshness_variable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFreshness_variable" ):
                listener.enterFreshness_variable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFreshness_variable" ):
                listener.exitFreshness_variable(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFreshness_variable" ):
                return visitor.visitFreshness_variable(self)
            else:
                return visitor.visitChildren(self)




    def freshness_variable(self):

        localctx = SodaCLAntlrParser.Freshness_variableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_freshness_variable)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 103
            self.match(SodaCLAntlrParser.S)
            self.state = 104
            self.match(SodaCLAntlrParser.T__1)
            self.state = 105
            self.match(SodaCLAntlrParser.S)
            self.state = 106
            self.identifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Warn_qualifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self):
            return self.getToken(SodaCLAntlrParser.S, 0)

        def WARN(self):
            return self.getToken(SodaCLAntlrParser.WARN, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_warn_qualifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWarn_qualifier" ):
                listener.enterWarn_qualifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWarn_qualifier" ):
                listener.exitWarn_qualifier(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWarn_qualifier" ):
                return visitor.visitWarn_qualifier(self)
            else:
                return visitor.visitChildren(self)




    def warn_qualifier(self):

        localctx = SodaCLAntlrParser.Warn_qualifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_warn_qualifier)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 108
            self.match(SodaCLAntlrParser.S)
            self.state = 109
            self.match(SodaCLAntlrParser.WARN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Failed_rows_checkContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER_DOUBLE_QUOTE(self):
            return self.getToken(SodaCLAntlrParser.IDENTIFIER_DOUBLE_QUOTE, 0)

        def EOF(self):
            return self.getToken(SodaCLAntlrParser.EOF, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_failed_rows_check

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFailed_rows_check" ):
                listener.enterFailed_rows_check(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFailed_rows_check" ):
                listener.exitFailed_rows_check(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFailed_rows_check" ):
                return visitor.visitFailed_rows_check(self)
            else:
                return visitor.visitChildren(self)




    def failed_rows_check(self):

        localctx = SodaCLAntlrParser.Failed_rows_checkContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_failed_rows_check)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 111
            self.match(SodaCLAntlrParser.IDENTIFIER_DOUBLE_QUOTE)
            self.state = 112
            self.match(SodaCLAntlrParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Row_count_comparison_checkContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def identifier(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SodaCLAntlrParser.IdentifierContext)
            else:
                return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,i)


        def EOF(self):
            return self.getToken(SodaCLAntlrParser.EOF, 0)

        def partition_name(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Partition_nameContext,0)


        def IN(self):
            return self.getToken(SodaCLAntlrParser.IN, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_row_count_comparison_check

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRow_count_comparison_check" ):
                listener.enterRow_count_comparison_check(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRow_count_comparison_check" ):
                listener.exitRow_count_comparison_check(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRow_count_comparison_check" ):
                return visitor.visitRow_count_comparison_check(self)
            else:
                return visitor.visitChildren(self)




    def row_count_comparison_check(self):

        localctx = SodaCLAntlrParser.Row_count_comparison_checkContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_row_count_comparison_check)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 114
            self.match(SodaCLAntlrParser.T__2)
            self.state = 115
            self.match(SodaCLAntlrParser.S)
            self.state = 116
            self.identifier()
            self.state = 119
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
            if la_ == 1:
                self.state = 117
                self.match(SodaCLAntlrParser.S)
                self.state = 118
                self.partition_name()


            self.state = 125
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==55:
                self.state = 121
                self.match(SodaCLAntlrParser.S)
                self.state = 122
                self.match(SodaCLAntlrParser.IN)
                self.state = 123
                self.match(SodaCLAntlrParser.S)
                self.state = 124
                self.identifier()


            self.state = 127
            self.match(SodaCLAntlrParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Metric_checkContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def metric(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.MetricContext,0)


        def EOF(self):
            return self.getToken(SodaCLAntlrParser.EOF, 0)

        def change_over_time(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Change_over_timeContext,0)


        def anomaly_score(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Anomaly_scoreContext,0)


        def S(self):
            return self.getToken(SodaCLAntlrParser.S, 0)

        def threshold(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.ThresholdContext,0)


        def default_anomaly_threshold(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Default_anomaly_thresholdContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_metric_check

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMetric_check" ):
                listener.enterMetric_check(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMetric_check" ):
                listener.exitMetric_check(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMetric_check" ):
                return visitor.visitMetric_check(self)
            else:
                return visitor.visitChildren(self)




    def metric_check(self):

        localctx = SodaCLAntlrParser.Metric_checkContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_metric_check)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 131
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [28]:
                self.state = 129
                self.change_over_time()
                pass
            elif token in [7]:
                self.state = 130
                self.anomaly_score()
                pass
            elif token in [30, 31, 32, 50, 51, 52]:
                pass
            else:
                pass
            self.state = 133
            self.metric()
            self.state = 139
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==55:
                self.state = 134
                self.match(SodaCLAntlrParser.S)
                self.state = 137
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
                if la_ == 1:
                    self.state = 135
                    self.threshold()
                    pass

                elif la_ == 2:
                    self.state = 136
                    self.default_anomaly_threshold()
                    pass




            self.state = 141
            self.match(SodaCLAntlrParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Default_anomaly_thresholdContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LT(self):
            return self.getToken(SodaCLAntlrParser.LT, 0)

        def S(self):
            return self.getToken(SodaCLAntlrParser.S, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_default_anomaly_threshold

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDefault_anomaly_threshold" ):
                listener.enterDefault_anomaly_threshold(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDefault_anomaly_threshold" ):
                listener.exitDefault_anomaly_threshold(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDefault_anomaly_threshold" ):
                return visitor.visitDefault_anomaly_threshold(self)
            else:
                return visitor.visitChildren(self)




    def default_anomaly_threshold(self):

        localctx = SodaCLAntlrParser.Default_anomaly_thresholdContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_default_anomaly_threshold)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 143
            self.match(SodaCLAntlrParser.LT)
            self.state = 144
            self.match(SodaCLAntlrParser.S)
            self.state = 145
            self.match(SodaCLAntlrParser.T__3)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Change_over_timeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CHANGE(self):
            return self.getToken(SodaCLAntlrParser.CHANGE, 0)

        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def FOR(self):
            return self.getToken(SodaCLAntlrParser.FOR, 0)

        def change_over_time_config(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Change_over_time_configContext,0)


        def percent(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.PercentContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_change_over_time

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterChange_over_time" ):
                listener.enterChange_over_time(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitChange_over_time" ):
                listener.exitChange_over_time(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitChange_over_time" ):
                return visitor.visitChange_over_time(self)
            else:
                return visitor.visitChildren(self)




    def change_over_time(self):

        localctx = SodaCLAntlrParser.Change_over_timeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_change_over_time)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 147
            self.match(SodaCLAntlrParser.CHANGE)
            self.state = 148
            self.match(SodaCLAntlrParser.S)
            self.state = 152
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if ((_la) & ~0x3f) == 0 and ((1 << _la) & 7516192800) != 0:
                self.state = 149
                self.change_over_time_config()
                self.state = 150
                self.match(SodaCLAntlrParser.S)


            self.state = 155
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==6:
                self.state = 154
                self.percent()


            self.state = 157
            self.match(SodaCLAntlrParser.FOR)
            self.state = 158
            self.match(SodaCLAntlrParser.S)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Change_over_time_configContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def change_aggregation(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Change_aggregationContext,0)


        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def LAST(self):
            return self.getToken(SodaCLAntlrParser.LAST, 0)

        def integer(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IntegerContext,0)


        def same_day_last_week(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Same_day_last_weekContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_change_over_time_config

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterChange_over_time_config" ):
                listener.enterChange_over_time_config(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitChange_over_time_config" ):
                listener.exitChange_over_time_config(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitChange_over_time_config" ):
                return visitor.visitChange_over_time_config(self)
            else:
                return visitor.visitChildren(self)




    def change_over_time_config(self):

        localctx = SodaCLAntlrParser.Change_over_time_configContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_change_over_time_config)
        try:
            self.state = 167
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [30, 31, 32]:
                self.enterOuterAlt(localctx, 1)
                self.state = 160
                self.change_aggregation()
                self.state = 161
                self.match(SodaCLAntlrParser.S)
                self.state = 162
                self.match(SodaCLAntlrParser.LAST)
                self.state = 163
                self.match(SodaCLAntlrParser.S)
                self.state = 164
                self.integer()
                pass
            elif token in [5]:
                self.enterOuterAlt(localctx, 2)
                self.state = 166
                self.same_day_last_week()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Change_aggregationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def AVG(self):
            return self.getToken(SodaCLAntlrParser.AVG, 0)

        def MIN(self):
            return self.getToken(SodaCLAntlrParser.MIN, 0)

        def MAX(self):
            return self.getToken(SodaCLAntlrParser.MAX, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_change_aggregation

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterChange_aggregation" ):
                listener.enterChange_aggregation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitChange_aggregation" ):
                listener.exitChange_aggregation(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitChange_aggregation" ):
                return visitor.visitChange_aggregation(self)
            else:
                return visitor.visitChildren(self)




    def change_aggregation(self):

        localctx = SodaCLAntlrParser.Change_aggregationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_change_aggregation)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 169
            _la = self._input.LA(1)
            if not(((_la) & ~0x3f) == 0 and ((1 << _la) & 7516192768) != 0):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Same_day_last_weekContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_same_day_last_week

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSame_day_last_week" ):
                listener.enterSame_day_last_week(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSame_day_last_week" ):
                listener.exitSame_day_last_week(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSame_day_last_week" ):
                return visitor.visitSame_day_last_week(self)
            else:
                return visitor.visitChildren(self)




    def same_day_last_week(self):

        localctx = SodaCLAntlrParser.Same_day_last_weekContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_same_day_last_week)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 171
            self.match(SodaCLAntlrParser.T__4)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PercentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self):
            return self.getToken(SodaCLAntlrParser.S, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_percent

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPercent" ):
                listener.enterPercent(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPercent" ):
                listener.exitPercent(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPercent" ):
                return visitor.visitPercent(self)
            else:
                return visitor.visitChildren(self)




    def percent(self):

        localctx = SodaCLAntlrParser.PercentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_percent)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 173
            self.match(SodaCLAntlrParser.T__5)
            self.state = 174
            self.match(SodaCLAntlrParser.S)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Anomaly_scoreContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_anomaly_score

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAnomaly_score" ):
                listener.enterAnomaly_score(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAnomaly_score" ):
                listener.exitAnomaly_score(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAnomaly_score" ):
                return visitor.visitAnomaly_score(self)
            else:
                return visitor.visitChildren(self)




    def anomaly_score(self):

        localctx = SodaCLAntlrParser.Anomaly_scoreContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_anomaly_score)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 176
            self.match(SodaCLAntlrParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MetricContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def metric_name(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Metric_nameContext,0)


        def metric_args(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Metric_argsContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_metric

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMetric" ):
                listener.enterMetric(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMetric" ):
                listener.exitMetric(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMetric" ):
                return visitor.visitMetric(self)
            else:
                return visitor.visitChildren(self)




    def metric(self):

        localctx = SodaCLAntlrParser.MetricContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_metric)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 178
            self.metric_name()
            self.state = 180
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==37:
                self.state = 179
                self.metric_args()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Metric_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_metric_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMetric_name" ):
                listener.enterMetric_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMetric_name" ):
                listener.exitMetric_name(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMetric_name" ):
                return visitor.visitMetric_name(self)
            else:
                return visitor.visitChildren(self)




    def metric_name(self):

        localctx = SodaCLAntlrParser.Metric_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_metric_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 182
            self.identifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Metric_argsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ROUND_LEFT(self):
            return self.getToken(SodaCLAntlrParser.ROUND_LEFT, 0)

        def metric_arg(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SodaCLAntlrParser.Metric_argContext)
            else:
                return self.getTypedRuleContext(SodaCLAntlrParser.Metric_argContext,i)


        def ROUND_RIGHT(self):
            return self.getToken(SodaCLAntlrParser.ROUND_RIGHT, 0)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.COMMA)
            else:
                return self.getToken(SodaCLAntlrParser.COMMA, i)

        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_metric_args

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMetric_args" ):
                listener.enterMetric_args(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMetric_args" ):
                listener.exitMetric_args(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMetric_args" ):
                return visitor.visitMetric_args(self)
            else:
                return visitor.visitChildren(self)




    def metric_args(self):

        localctx = SodaCLAntlrParser.Metric_argsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_metric_args)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 184
            self.match(SodaCLAntlrParser.ROUND_LEFT)
            self.state = 185
            self.metric_arg()
            self.state = 191
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==39:
                self.state = 186
                self.match(SodaCLAntlrParser.COMMA)
                self.state = 187
                self.match(SodaCLAntlrParser.S)
                self.state = 188
                self.metric_arg()
                self.state = 193
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 194
            self.match(SodaCLAntlrParser.ROUND_RIGHT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Metric_argContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def signed_number(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Signed_numberContext,0)


        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_metric_arg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMetric_arg" ):
                listener.enterMetric_arg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMetric_arg" ):
                listener.exitMetric_arg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMetric_arg" ):
                return visitor.visitMetric_arg(self)
            else:
                return visitor.visitChildren(self)




    def metric_arg(self):

        localctx = SodaCLAntlrParser.Metric_argContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_metric_arg)
        try:
            self.state = 198
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [19, 41, 42, 54]:
                self.enterOuterAlt(localctx, 1)
                self.state = 196
                self.signed_number()
                pass
            elif token in [30, 31, 32, 50, 51, 52]:
                self.enterOuterAlt(localctx, 2)
                self.state = 197
                self.identifier()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ThresholdContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def comparator_threshold(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Comparator_thresholdContext,0)


        def between_threshold(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Between_thresholdContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_threshold

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterThreshold" ):
                listener.enterThreshold(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitThreshold" ):
                listener.exitThreshold(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitThreshold" ):
                return visitor.visitThreshold(self)
            else:
                return visitor.visitChildren(self)




    def threshold(self):

        localctx = SodaCLAntlrParser.ThresholdContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_threshold)
        try:
            self.state = 202
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [43, 44, 45, 46, 47, 48, 49]:
                self.enterOuterAlt(localctx, 1)
                self.state = 200
                self.comparator_threshold()
                pass
            elif token in [22, 23]:
                self.enterOuterAlt(localctx, 2)
                self.state = 201
                self.between_threshold()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Between_thresholdContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BETWEEN(self):
            return self.getToken(SodaCLAntlrParser.BETWEEN, 0)

        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def threshold_value(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SodaCLAntlrParser.Threshold_valueContext)
            else:
                return self.getTypedRuleContext(SodaCLAntlrParser.Threshold_valueContext,i)


        def AND(self):
            return self.getToken(SodaCLAntlrParser.AND, 0)

        def NOT(self):
            return self.getToken(SodaCLAntlrParser.NOT, 0)

        def SQUARE_LEFT(self):
            return self.getToken(SodaCLAntlrParser.SQUARE_LEFT, 0)

        def ROUND_LEFT(self):
            return self.getToken(SodaCLAntlrParser.ROUND_LEFT, 0)

        def SQUARE_RIGHT(self):
            return self.getToken(SodaCLAntlrParser.SQUARE_RIGHT, 0)

        def ROUND_RIGHT(self):
            return self.getToken(SodaCLAntlrParser.ROUND_RIGHT, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_between_threshold

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBetween_threshold" ):
                listener.enterBetween_threshold(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBetween_threshold" ):
                listener.exitBetween_threshold(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBetween_threshold" ):
                return visitor.visitBetween_threshold(self)
            else:
                return visitor.visitChildren(self)




    def between_threshold(self):

        localctx = SodaCLAntlrParser.Between_thresholdContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_between_threshold)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 206
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==23:
                self.state = 204
                self.match(SodaCLAntlrParser.NOT)
                self.state = 205
                self.match(SodaCLAntlrParser.S)


            self.state = 208
            self.match(SodaCLAntlrParser.BETWEEN)
            self.state = 209
            self.match(SodaCLAntlrParser.S)
            self.state = 211
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33 or _la==37:
                self.state = 210
                _la = self._input.LA(1)
                if not(_la==33 or _la==37):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


            self.state = 213
            self.threshold_value()
            self.state = 214
            self.match(SodaCLAntlrParser.S)
            self.state = 215
            self.match(SodaCLAntlrParser.AND)
            self.state = 216
            self.match(SodaCLAntlrParser.S)
            self.state = 217
            self.threshold_value()
            self.state = 219
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==34 or _la==38:
                self.state = 218
                _la = self._input.LA(1)
                if not(_la==34 or _la==38):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Comparator_thresholdContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def comparator(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.ComparatorContext,0)


        def S(self):
            return self.getToken(SodaCLAntlrParser.S, 0)

        def threshold_value(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Threshold_valueContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_comparator_threshold

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComparator_threshold" ):
                listener.enterComparator_threshold(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComparator_threshold" ):
                listener.exitComparator_threshold(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComparator_threshold" ):
                return visitor.visitComparator_threshold(self)
            else:
                return visitor.visitChildren(self)




    def comparator_threshold(self):

        localctx = SodaCLAntlrParser.Comparator_thresholdContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_comparator_threshold)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 221
            self.comparator()
            self.state = 222
            self.match(SodaCLAntlrParser.S)
            self.state = 223
            self.threshold_value()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Zones_thresholdContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def outcome(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SodaCLAntlrParser.OutcomeContext)
            else:
                return self.getTypedRuleContext(SodaCLAntlrParser.OutcomeContext,i)


        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def zone_comparator(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SodaCLAntlrParser.Zone_comparatorContext)
            else:
                return self.getTypedRuleContext(SodaCLAntlrParser.Zone_comparatorContext,i)


        def threshold_value(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SodaCLAntlrParser.Threshold_valueContext)
            else:
                return self.getTypedRuleContext(SodaCLAntlrParser.Threshold_valueContext,i)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_zones_threshold

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterZones_threshold" ):
                listener.enterZones_threshold(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitZones_threshold" ):
                listener.exitZones_threshold(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitZones_threshold" ):
                return visitor.visitZones_threshold(self)
            else:
                return visitor.visitChildren(self)




    def zones_threshold(self):

        localctx = SodaCLAntlrParser.Zones_thresholdContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_zones_threshold)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 234 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 225
                    self.outcome()
                    self.state = 226
                    self.match(SodaCLAntlrParser.S)
                    self.state = 227
                    self.zone_comparator()
                    self.state = 228
                    self.match(SodaCLAntlrParser.S)
                    self.state = 229
                    self.threshold_value()
                    self.state = 230
                    self.match(SodaCLAntlrParser.S)
                    self.state = 231
                    self.zone_comparator()
                    self.state = 232
                    self.match(SodaCLAntlrParser.S)

                else:
                    raise NoViableAltException(self)
                self.state = 236 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,18,self._ctx)

            self.state = 238
            self.outcome()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OutcomeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WARN(self):
            return self.getToken(SodaCLAntlrParser.WARN, 0)

        def FAIL(self):
            return self.getToken(SodaCLAntlrParser.FAIL, 0)

        def PASS(self):
            return self.getToken(SodaCLAntlrParser.PASS, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_outcome

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOutcome" ):
                listener.enterOutcome(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOutcome" ):
                listener.exitOutcome(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOutcome" ):
                return visitor.visitOutcome(self)
            else:
                return visitor.visitChildren(self)




    def outcome(self):

        localctx = SodaCLAntlrParser.OutcomeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_outcome)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 240
            _la = self._input.LA(1)
            if not(((_la) & ~0x3f) == 0 and ((1 << _la) & 234881024) != 0):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Zone_comparatorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LT(self):
            return self.getToken(SodaCLAntlrParser.LT, 0)

        def LTE(self):
            return self.getToken(SodaCLAntlrParser.LTE, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_zone_comparator

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterZone_comparator" ):
                listener.enterZone_comparator(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitZone_comparator" ):
                listener.exitZone_comparator(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitZone_comparator" ):
                return visitor.visitZone_comparator(self)
            else:
                return visitor.visitChildren(self)




    def zone_comparator(self):

        localctx = SodaCLAntlrParser.Zone_comparatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_zone_comparator)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 242
            _la = self._input.LA(1)
            if not(_la==45 or _la==48):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ComparatorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LT(self):
            return self.getToken(SodaCLAntlrParser.LT, 0)

        def LTE(self):
            return self.getToken(SodaCLAntlrParser.LTE, 0)

        def EQUAL(self):
            return self.getToken(SodaCLAntlrParser.EQUAL, 0)

        def GTE(self):
            return self.getToken(SodaCLAntlrParser.GTE, 0)

        def GT(self):
            return self.getToken(SodaCLAntlrParser.GT, 0)

        def NOT_EQUAL(self):
            return self.getToken(SodaCLAntlrParser.NOT_EQUAL, 0)

        def NOT_EQUAL_SQL(self):
            return self.getToken(SodaCLAntlrParser.NOT_EQUAL_SQL, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_comparator

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComparator" ):
                listener.enterComparator(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComparator" ):
                listener.exitComparator(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComparator" ):
                return visitor.visitComparator(self)
            else:
                return visitor.visitChildren(self)




    def comparator(self):

        localctx = SodaCLAntlrParser.ComparatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_comparator)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 244
            _la = self._input.LA(1)
            if not(((_la) & ~0x3f) == 0 and ((1 << _la) & 1117103813820416) != 0):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Threshold_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def signed_number(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Signed_numberContext,0)


        def PERCENT(self):
            return self.getToken(SodaCLAntlrParser.PERCENT, 0)

        def S(self):
            return self.getToken(SodaCLAntlrParser.S, 0)

        def freshness_threshold_value(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Freshness_threshold_valueContext,0)


        def IDENTIFIER_UNQUOTED(self):
            return self.getToken(SodaCLAntlrParser.IDENTIFIER_UNQUOTED, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_threshold_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterThreshold_value" ):
                listener.enterThreshold_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitThreshold_value" ):
                listener.exitThreshold_value(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitThreshold_value" ):
                return visitor.visitThreshold_value(self)
            else:
                return visitor.visitChildren(self)




    def threshold_value(self):

        localctx = SodaCLAntlrParser.Threshold_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_threshold_value)
        self._la = 0 # Token type
        try:
            self.state = 255
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,21,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 246
                self.signed_number()
                self.state = 251
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,20,self._ctx)
                if la_ == 1:
                    self.state = 248
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if _la==55:
                        self.state = 247
                        self.match(SodaCLAntlrParser.S)


                    self.state = 250
                    self.match(SodaCLAntlrParser.PERCENT)


                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 253
                self.freshness_threshold_value()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 254
                self.match(SodaCLAntlrParser.IDENTIFIER_UNQUOTED)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Freshness_threshold_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def integer(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SodaCLAntlrParser.IntegerContext)
            else:
                return self.getTypedRuleContext(SodaCLAntlrParser.IntegerContext,i)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_freshness_threshold_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFreshness_threshold_value" ):
                listener.enterFreshness_threshold_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFreshness_threshold_value" ):
                listener.exitFreshness_threshold_value(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFreshness_threshold_value" ):
                return visitor.visitFreshness_threshold_value(self)
            else:
                return visitor.visitChildren(self)




    def freshness_threshold_value(self):

        localctx = SodaCLAntlrParser.Freshness_threshold_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_freshness_threshold_value)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 260 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 257
                    self.integer()
                    self.state = 258
                    _la = self._input.LA(1)
                    if not(((_la) & ~0x3f) == 0 and ((1 << _la) & 1792) != 0):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()

                else:
                    raise NoViableAltException(self)
                self.state = 262 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,22,self._ctx)

            self.state = 265
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==54:
                self.state = 264
                self.integer()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Reference_checkContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def source_column_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SodaCLAntlrParser.Source_column_nameContext)
            else:
                return self.getTypedRuleContext(SodaCLAntlrParser.Source_column_nameContext,i)


        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def target_column_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SodaCLAntlrParser.Target_column_nameContext)
            else:
                return self.getTypedRuleContext(SodaCLAntlrParser.Target_column_nameContext,i)


        def ROUND_LEFT(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.ROUND_LEFT)
            else:
                return self.getToken(SodaCLAntlrParser.ROUND_LEFT, i)

        def ROUND_RIGHT(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.ROUND_RIGHT)
            else:
                return self.getToken(SodaCLAntlrParser.ROUND_RIGHT, i)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.COMMA)
            else:
                return self.getToken(SodaCLAntlrParser.COMMA, i)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_reference_check

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterReference_check" ):
                listener.enterReference_check(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitReference_check" ):
                listener.exitReference_check(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitReference_check" ):
                return visitor.visitReference_check(self)
            else:
                return visitor.visitChildren(self)




    def reference_check(self):

        localctx = SodaCLAntlrParser.Reference_checkContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_reference_check)
        self._la = 0 # Token type
        try:
            self.state = 307
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,26,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 267
                self.match(SodaCLAntlrParser.T__10)
                self.state = 268
                self.match(SodaCLAntlrParser.S)
                self.state = 269
                self.source_column_name()
                self.state = 270
                self.match(SodaCLAntlrParser.S)
                self.state = 271
                self.match(SodaCLAntlrParser.T__11)
                self.state = 272
                self.match(SodaCLAntlrParser.S)
                self.state = 273
                self.identifier()
                self.state = 274
                self.match(SodaCLAntlrParser.S)
                self.state = 275
                self.target_column_name()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 277
                self.match(SodaCLAntlrParser.T__10)
                self.state = 278
                self.match(SodaCLAntlrParser.S)
                self.state = 279
                self.match(SodaCLAntlrParser.ROUND_LEFT)
                self.state = 280
                self.source_column_name()
                self.state = 286
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==39:
                    self.state = 281
                    self.match(SodaCLAntlrParser.COMMA)
                    self.state = 282
                    self.match(SodaCLAntlrParser.S)
                    self.state = 283
                    self.source_column_name()
                    self.state = 288
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 289
                self.match(SodaCLAntlrParser.ROUND_RIGHT)
                self.state = 290
                self.match(SodaCLAntlrParser.S)
                self.state = 291
                self.match(SodaCLAntlrParser.T__11)
                self.state = 292
                self.match(SodaCLAntlrParser.S)
                self.state = 293
                self.identifier()
                self.state = 294
                self.match(SodaCLAntlrParser.S)
                self.state = 295
                self.match(SodaCLAntlrParser.ROUND_LEFT)
                self.state = 296
                self.target_column_name()
                self.state = 302
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==39:
                    self.state = 297
                    self.match(SodaCLAntlrParser.COMMA)
                    self.state = 298
                    self.match(SodaCLAntlrParser.S)
                    self.state = 299
                    self.target_column_name()
                    self.state = 304
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 305
                self.match(SodaCLAntlrParser.ROUND_RIGHT)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Source_column_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_source_column_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSource_column_name" ):
                listener.enterSource_column_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSource_column_name" ):
                listener.exitSource_column_name(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSource_column_name" ):
                return visitor.visitSource_column_name(self)
            else:
                return visitor.visitChildren(self)




    def source_column_name(self):

        localctx = SodaCLAntlrParser.Source_column_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_source_column_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 309
            self.identifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Target_column_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_target_column_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTarget_column_name" ):
                listener.enterTarget_column_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTarget_column_name" ):
                listener.exitTarget_column_name(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTarget_column_name" ):
                return visitor.visitTarget_column_name(self)
            else:
                return visitor.visitChildren(self)




    def target_column_name(self):

        localctx = SodaCLAntlrParser.Target_column_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_target_column_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 311
            self.identifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Section_headerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def table_checks_header(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Table_checks_headerContext,0)


        def column_configurations_header(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Column_configurations_headerContext,0)


        def table_filter_header(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Table_filter_headerContext,0)


        def checks_for_each_dataset_header(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Checks_for_each_dataset_headerContext,0)


        def checks_for_each_column_header(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Checks_for_each_column_headerContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_section_header

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSection_header" ):
                listener.enterSection_header(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSection_header" ):
                listener.exitSection_header(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSection_header" ):
                return visitor.visitSection_header(self)
            else:
                return visitor.visitChildren(self)




    def section_header(self):

        localctx = SodaCLAntlrParser.Section_headerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_section_header)
        try:
            self.state = 318
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [13]:
                self.enterOuterAlt(localctx, 1)
                self.state = 313
                self.table_checks_header()
                pass
            elif token in [15]:
                self.enterOuterAlt(localctx, 2)
                self.state = 314
                self.column_configurations_header()
                pass
            elif token in [14]:
                self.enterOuterAlt(localctx, 3)
                self.state = 315
                self.table_filter_header()
                pass
            elif token in [16, 17]:
                self.enterOuterAlt(localctx, 4)
                self.state = 316
                self.checks_for_each_dataset_header()
                pass
            elif token in [18]:
                self.enterOuterAlt(localctx, 5)
                self.state = 317
                self.checks_for_each_column_header()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Table_checks_headerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def EOF(self):
            return self.getToken(SodaCLAntlrParser.EOF, 0)

        def partition_name(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Partition_nameContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_table_checks_header

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTable_checks_header" ):
                listener.enterTable_checks_header(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTable_checks_header" ):
                listener.exitTable_checks_header(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTable_checks_header" ):
                return visitor.visitTable_checks_header(self)
            else:
                return visitor.visitChildren(self)




    def table_checks_header(self):

        localctx = SodaCLAntlrParser.Table_checks_headerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_table_checks_header)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 320
            self.match(SodaCLAntlrParser.T__12)
            self.state = 321
            self.match(SodaCLAntlrParser.S)
            self.state = 322
            self.identifier()
            self.state = 325
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==55:
                self.state = 323
                self.match(SodaCLAntlrParser.S)
                self.state = 324
                self.partition_name()


            self.state = 327
            self.match(SodaCLAntlrParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Partition_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SQUARE_LEFT(self):
            return self.getToken(SodaCLAntlrParser.SQUARE_LEFT, 0)

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def SQUARE_RIGHT(self):
            return self.getToken(SodaCLAntlrParser.SQUARE_RIGHT, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_partition_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPartition_name" ):
                listener.enterPartition_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPartition_name" ):
                listener.exitPartition_name(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPartition_name" ):
                return visitor.visitPartition_name(self)
            else:
                return visitor.visitChildren(self)




    def partition_name(self):

        localctx = SodaCLAntlrParser.Partition_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_partition_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 329
            self.match(SodaCLAntlrParser.SQUARE_LEFT)
            self.state = 330
            self.identifier()
            self.state = 331
            self.match(SodaCLAntlrParser.SQUARE_RIGHT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Table_filter_headerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def partition_name(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Partition_nameContext,0)


        def EOF(self):
            return self.getToken(SodaCLAntlrParser.EOF, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_table_filter_header

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTable_filter_header" ):
                listener.enterTable_filter_header(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTable_filter_header" ):
                listener.exitTable_filter_header(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTable_filter_header" ):
                return visitor.visitTable_filter_header(self)
            else:
                return visitor.visitChildren(self)




    def table_filter_header(self):

        localctx = SodaCLAntlrParser.Table_filter_headerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_table_filter_header)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 333
            self.match(SodaCLAntlrParser.T__13)
            self.state = 334
            self.match(SodaCLAntlrParser.S)
            self.state = 335
            self.identifier()
            self.state = 336
            self.match(SodaCLAntlrParser.S)
            self.state = 337
            self.partition_name()
            self.state = 338
            self.match(SodaCLAntlrParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Column_configurations_headerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self):
            return self.getToken(SodaCLAntlrParser.S, 0)

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def EOF(self):
            return self.getToken(SodaCLAntlrParser.EOF, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_column_configurations_header

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterColumn_configurations_header" ):
                listener.enterColumn_configurations_header(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitColumn_configurations_header" ):
                listener.exitColumn_configurations_header(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitColumn_configurations_header" ):
                return visitor.visitColumn_configurations_header(self)
            else:
                return visitor.visitChildren(self)




    def column_configurations_header(self):

        localctx = SodaCLAntlrParser.Column_configurations_headerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_column_configurations_header)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 340
            self.match(SodaCLAntlrParser.T__14)
            self.state = 341
            self.match(SodaCLAntlrParser.S)
            self.state = 342
            self.identifier()
            self.state = 343
            self.match(SodaCLAntlrParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Checks_for_each_dataset_headerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self):
            return self.getToken(SodaCLAntlrParser.S, 0)

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def EOF(self):
            return self.getToken(SodaCLAntlrParser.EOF, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_checks_for_each_dataset_header

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterChecks_for_each_dataset_header" ):
                listener.enterChecks_for_each_dataset_header(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitChecks_for_each_dataset_header" ):
                listener.exitChecks_for_each_dataset_header(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitChecks_for_each_dataset_header" ):
                return visitor.visitChecks_for_each_dataset_header(self)
            else:
                return visitor.visitChildren(self)




    def checks_for_each_dataset_header(self):

        localctx = SodaCLAntlrParser.Checks_for_each_dataset_headerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_checks_for_each_dataset_header)
        try:
            self.state = 355
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [16]:
                self.enterOuterAlt(localctx, 1)
                self.state = 345
                self.match(SodaCLAntlrParser.T__15)
                self.state = 346
                self.match(SodaCLAntlrParser.S)
                self.state = 347
                self.identifier()
                self.state = 348
                self.match(SodaCLAntlrParser.EOF)
                pass
            elif token in [17]:
                self.enterOuterAlt(localctx, 2)
                self.state = 350
                self.match(SodaCLAntlrParser.T__16)
                self.state = 351
                self.match(SodaCLAntlrParser.S)
                self.state = 352
                self.identifier()
                self.state = 353
                self.match(SodaCLAntlrParser.EOF)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Checks_for_each_column_headerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self):
            return self.getToken(SodaCLAntlrParser.S, 0)

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def EOF(self):
            return self.getToken(SodaCLAntlrParser.EOF, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_checks_for_each_column_header

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterChecks_for_each_column_header" ):
                listener.enterChecks_for_each_column_header(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitChecks_for_each_column_header" ):
                listener.exitChecks_for_each_column_header(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitChecks_for_each_column_header" ):
                return visitor.visitChecks_for_each_column_header(self)
            else:
                return visitor.visitChildren(self)




    def checks_for_each_column_header(self):

        localctx = SodaCLAntlrParser.Checks_for_each_column_headerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_checks_for_each_column_header)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 357
            self.match(SodaCLAntlrParser.T__17)
            self.state = 358
            self.match(SodaCLAntlrParser.S)
            self.state = 359
            self.identifier()
            self.state = 360
            self.match(SodaCLAntlrParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Signed_numberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def number(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.NumberContext,0)


        def PLUS(self):
            return self.getToken(SodaCLAntlrParser.PLUS, 0)

        def MINUS(self):
            return self.getToken(SodaCLAntlrParser.MINUS, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_signed_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSigned_number" ):
                listener.enterSigned_number(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSigned_number" ):
                listener.exitSigned_number(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSigned_number" ):
                return visitor.visitSigned_number(self)
            else:
                return visitor.visitChildren(self)




    def signed_number(self):

        localctx = SodaCLAntlrParser.Signed_numberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_signed_number)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 363
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==41 or _la==42:
                self.state = 362
                _la = self._input.LA(1)
                if not(_la==41 or _la==42):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


            self.state = 365
            self.number()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def integer(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IntegerContext,0)


        def DIGITS(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.DIGITS)
            else:
                return self.getToken(SodaCLAntlrParser.DIGITS, i)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNumber" ):
                return visitor.visitNumber(self)
            else:
                return visitor.visitChildren(self)




    def number(self):

        localctx = SodaCLAntlrParser.NumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_number)
        self._la = 0 # Token type
        try:
            self.state = 378
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,33,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 367
                self.integer()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 368
                self.match(SodaCLAntlrParser.DIGITS)
                self.state = 369
                self.match(SodaCLAntlrParser.T__18)
                self.state = 371
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==54:
                    self.state = 370
                    self.match(SodaCLAntlrParser.DIGITS)


                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 374
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==54:
                    self.state = 373
                    self.match(SodaCLAntlrParser.DIGITS)


                self.state = 376
                self.match(SodaCLAntlrParser.T__18)
                self.state = 377
                self.match(SodaCLAntlrParser.DIGITS)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IntegerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DIGITS(self):
            return self.getToken(SodaCLAntlrParser.DIGITS, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_integer

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInteger" ):
                listener.enterInteger(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInteger" ):
                listener.exitInteger(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInteger" ):
                return visitor.visitInteger(self)
            else:
                return visitor.visitChildren(self)




    def integer(self):

        localctx = SodaCLAntlrParser.IntegerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_integer)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 380
            self.match(SodaCLAntlrParser.DIGITS)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdentifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER_UNQUOTED(self):
            return self.getToken(SodaCLAntlrParser.IDENTIFIER_UNQUOTED, 0)

        def IDENTIFIER_DOUBLE_QUOTE(self):
            return self.getToken(SodaCLAntlrParser.IDENTIFIER_DOUBLE_QUOTE, 0)

        def IDENTIFIER_BACKTICK(self):
            return self.getToken(SodaCLAntlrParser.IDENTIFIER_BACKTICK, 0)

        def MIN(self):
            return self.getToken(SodaCLAntlrParser.MIN, 0)

        def MAX(self):
            return self.getToken(SodaCLAntlrParser.MAX, 0)

        def AVG(self):
            return self.getToken(SodaCLAntlrParser.AVG, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_identifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdentifier" ):
                listener.enterIdentifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdentifier" ):
                listener.exitIdentifier(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIdentifier" ):
                return visitor.visitIdentifier(self)
            else:
                return visitor.visitChildren(self)




    def identifier(self):

        localctx = SodaCLAntlrParser.IdentifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_identifier)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 382
            _la = self._input.LA(1)
            if not(((_la) & ~0x3f) == 0 and ((1 << _la) & 7881306864091136) != 0):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





