class FileCfg:
    def __init__(self, file_path: str):
        self.file_path = file_path
