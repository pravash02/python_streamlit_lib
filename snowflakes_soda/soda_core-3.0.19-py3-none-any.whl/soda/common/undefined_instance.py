class Undefined:
    pass


undefined = Undefined()
